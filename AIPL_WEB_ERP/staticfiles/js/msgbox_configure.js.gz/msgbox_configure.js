// for customer dashboard

box = document.getElementsByClassName("success")[0].style
box.padding = "7px"
box.top = "47px"

box2 = document.getElementsByClassName("error")[0].style
box2.padding = "7px"
box2.top = "47px"